
/* XXX ERROR -- could not find '++resource++collective.cover/bootstrap.min.js'*/
